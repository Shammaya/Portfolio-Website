export const Zidane = {
   name: 'Zidane',
   home: {
      profile: "Professional Programmer with more than 3 years of experience in web application development for Ontario Public Service, locating and delivering technical supports and solutions on application malfunctions. Proficient in user interface design/creation, restful API (Application Programming Interface), artificial intelligence, automation testing, programming, debugging, encryption, decryption, authentication, database management. Looking for new opportunities in a new company with new challenges to grow my expertise. ",
     
   }
      
  
    
  }